#import <UIKit/UIKit.h>

@interface UIColor (MoreYellow)

+ (UIColor *) amberColor;

+ (UIColor *) aureolinColor;

+ (UIColor *) citrineColor;

@end
